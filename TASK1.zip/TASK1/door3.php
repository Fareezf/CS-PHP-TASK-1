<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo "<center>";
    echo "<h1>Welcome to Door 3</h1>";
    echo "<h2>This is the story of Re:Zero</h2>";
    echo "<p>Natsuki Subaru, an ordinary high school student, is suddenly transported to another world.<br> In this new world, he gains a unique ability:  by Death.<br> This ability allows him to rewind time to a specific point, reliving the same events over and over again.
<br><br>
Subaru uses this power to protect those he cares about,<br> but he soon realizes that the world he's been thrown into is far more cruel and unforgiving than he imagined.<br> As he faces repeated failures and heart-wrenching losses, Subaru must learn to accept the <br>harsh realities of his new life and find the strength to keep moving forward.</p>";
    echo '<button style="background-color: black; color: white; padding: 10px 20px; border: none; border-radius: 5px; font-size: 16px; cursor: pointer;" onclick="history.back()">Go Back</button>';
    echo "</center>";
}
?>