<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo "<center>";
    echo "<h1>Welcome to Door 1</h1>";
    echo "<h2>This is the story of Attack On Titan</h2>";
    echo "<p>In a world surrounded by colossal walls, humanity lives in fear of the Titans,<br> monstrous creatures that devour humans without remorse.<br> Eren Yeager, a young boy consumed by rage and a thirst for vengeance,<br> vows to exterminate the Titans after witnessing the destruction of his hometown and the death of his mother.
<br><br>
Joining the Survey Corps, an elite military unit <br>dedicated to fighting Titans beyond the walls,<br> Eren trains rigorously alongside his childhood friends,<br> Mikasa Ackerman and Armin Arlert. <br>Together, they face countless dangers and unravel the mysteries surrounding the Titans and the walls.
<br><br>
As Eren delves deeper into the truth, he discovers a <br>shocking secret about his own origins and the true nature of the Titans. His quest for <br>revenge becomes intertwined with the fate of humanity, leading him down <br>a path of sacrifice, loss, and the ultimate test of his resolve.</p>";
    echo '<button style="background-color: black; color: white; padding: 10px 20px; border: none; border-radius: 5px; font-size: 16px; cursor: pointer;" onclick="history.back()">Go Back</button>';
    echo "</center>";
}
?>