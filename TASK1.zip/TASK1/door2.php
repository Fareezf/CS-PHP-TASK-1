<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo "<center>";
    echo "<h1>Welcome to Door 2</h1>";
    echo "<h2>This is the story of One Piece</h2>";
    echo "<p>Monkey D. Luffy, a young boy with the ability to stretch his body like rubber,<br> dreams of becoming the King of the Pirates. Inspired by his childhood hero, <br>Gol D. Roger, Luffy sets sail with his crew, the Straw Hat Pirates, <br>to find the legendary treasure, the One Piece.
<br><br>
As they navigate the dangerous Grand Line, they encounter countless challenges, <br>from powerful pirates to mysterious islands and mythical creatures.<br> Luffy and his crew face trials that test their strength, courage, and friendship.<br> Through their adventures, they discover the true meaning of freedom, camaraderie, and the pursuit of one's dreams.</p>";
    echo '<button style="background-color: black; color: white; padding: 10px 20px; border: none; border-radius: 5px; font-size: 16px; cursor: pointer;" onclick="history.back()">Go Back</button>';
    echo "</center>";
}
?>